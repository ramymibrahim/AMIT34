<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(url('posts')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>    
        <input name="title" placeholder="Title" />
        <input name="image" placeholder="Image" />
        <input name="publish_date" type="date" placeholder="Publish Date" />
        <input name="category_id" placeholder="C id" />
        <input name="user_id" placeholder="U id" />
        <input name="content" placeholder="Content" />
        <button type="submit">Save</button>
    </form>
</body>

</html><?php /**PATH C:\xampp\htdocs\AMIT34\session9\blog\resources\views/create.blade.php ENDPATH**/ ?>