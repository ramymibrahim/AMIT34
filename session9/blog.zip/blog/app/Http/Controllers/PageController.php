<?php

namespace App\Http\Controllers;

use App\Post;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index()
    {
        $posts1 = Post::all();
        return view("posts")->with('posts2', $posts1);
    }

    public function show($id)
    {
        $post = Post::findOrFail($id);
        return view("show")->with('post',$post);
    }
    public function create()
    {
        return view('create');
    }

    public function store(Request $request){        
        $post = new Post();
        $post['title']=$request['title'];
        $post['image']=$request['image'];
        $post['publish_date']=$request['publish_date'];
        $post['category_id']=$request['category_id'];
        $post['user_id']=$request['user_id'];
        $post['content']=$request['content'];
        $post['rate']=1;
        $post['rate_count']=1;        
        $post->save();
        return redirect('posts');
    }
}
